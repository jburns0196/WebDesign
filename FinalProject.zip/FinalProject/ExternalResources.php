<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //title
        echo "<div style='text-align:center'><h1>External Resources</h1></div>";
        
        
        //to be worked on with database elements
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<a href='index.php'>Home</a>";
        echo "<hr>";
        //signature, thanking the user for visiting
        echo "<div style='text-align:center'>Made by Jeremy Burns. Thanks for visiting!</div>";
        ?>
    </body>
</html>
