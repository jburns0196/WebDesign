<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //title of the website, greeting the user
        echo "<div style='text-align:center'><h1>WARFAX</h1></div>";
        echo "<div style='text-align:center'>A handy site for those looking to delve into WARFRAME!</div>";
        echo "<br>"; 
        echo "<br>"; 
        echo "<br>"; 
        echo "<div style='text-align:center'>If you're here on this site, you likely already know what WARFRAME is. After a rough release in 2013, the unique squad-based 'MMO' has surged in popularity - and if you're not an old player, you've likely come aboard recently.</div>";
        echo "<br>"; 
        echo "<div style='text-align:center'>While certainly a fantastic game, one constantly highlighted issue about it is the lack of informational resources in-game.</div>";
        echo "<div style='text-align:center'>Tooltips aren't fleshed out, the drop locations of many items (important and not) aren't viewable, and numerous details are almost impossible to find out on your own.</div>";
        echo "<div style='text-align:center'><br>Thus; Warfax! This site is dedicated to helping both new players and veterans - in providing a simple and quick source of many guides, important details, and information you wouldn't regularly find.</div>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<div style='text-align:left'>You can take the following links to different sections of this site:</div>";
        echo "<hr>";
        echo "<br>";
        
        //links to separate pages and parts of the website
        echo "<a href='NewPlayers.php'>New Players</a>";
        echo '<p>This section is for players who are entirely new to the game; introductory guides, details on how best to start out, and tips on some of the harder to understand integral systems of the game are here!</p>';
        echo "<br>";
        echo "<a href='Guides.php'>Guides</a>";
        echo "<p>This is a section for both players with some experience and veterans. After all, the game updates almost weekly - with something completely new being added all the time.<br>Even veterans might be a bit lost with some more recent developments. Game modes, modding, new features, new levels; For all those needs, stop by here!</p>";
        echo "<br>";
        echo "<a href='TipsAndTricks.php'>Tips & Tricks</a>";
        echo "<p>Here is a set of helpful hints and tips that I've compiled over the years, on a number of different topics. New players, players with some experience, and veterans can all find something useful here.</p>";
        echo "<br>";
        echo "<a href='ExternalResources.php'>External Resources</a>";
        echo "<p>This page simply links to other helpful sites; the main Warframe website, Warframe Builder (a simulations site for modding), Warframe Market (a 3rd party site for trading), and so on.</p>";

        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<hr>";
        //signature, thanking the user for visiting
        echo "<div style='text-align:center'>Made by Jeremy Burns. Thanks for visiting!</div>";      
        ?>
    </body>
</html>
